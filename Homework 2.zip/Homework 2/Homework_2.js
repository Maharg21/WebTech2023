console.log("JavaScript Thing");
 // My Favorite sites to use is Youtube, Nexus Mods, and Google Docs (I'm not a big website type person)
       
// My 3 favorite games are Elden Ring, Subnautica, and Pizza Tower
// My 3 favorite artists: H.R Giger mainly for his surreal biochanical drawings (concept artist for Alien)
// Jeremy Soule (composer) known for writing music scores for games, but is also an indepenent composer (Composed Skyrim) 
// J.R.R Tolkien (author) for creating the whole rich world of Middle Earth and the Lord of the Rings 


